import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { ink: "#0F172A", accent: "#3B82F6", emergency: "#DC2626" } } },
  plugins: [],
} satisfies Config;
