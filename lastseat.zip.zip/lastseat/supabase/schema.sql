create table if not exists public.users (
  id uuid primary key references auth.users on delete cascade,
  email text, full_name text, phone text, created_at timestamptz default now());
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  pnr text unique not null,
  user_id uuid references public.users(id),
  flight_id text not null, origin text, destination text, flight_no text, departure timestamptz,
  passenger_name text, passenger_email text, passenger_phone text,
  amount_inr integer not null, discount_pct integer default 0,
  razorpay_order_id text, razorpay_payment_id text, created_at timestamptz default now());
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null, route text, discount_pct integer not null, created_at timestamptz default now());
alter table public.users enable row level security;
alter table public.bookings enable row level security;
alter table public.offers enable row level security;
create policy "own profile" on public.users for all using (auth.uid() = id);
create policy "own bookings" on public.bookings for select using (auth.uid() = user_id);
create policy "offers readable" on public.offers for select using (true);
-- Writes happen only through API routes using the service-role key.
