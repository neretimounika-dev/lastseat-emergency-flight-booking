// npm run build:android  ->  dist/lastseat.aab
import { execSync } from "node:child_process";
import { existsSync, mkdirSync, copyFileSync } from "node:fs";

const run = (cmd, cwd) => { console.log(`\n> ${cmd}`); execSync(cmd, { stdio: "inherit", cwd }); };

if (!process.env.CAP_SERVER_URL) {
  console.error("Set CAP_SERVER_URL to your deployed HTTPS URL first."); process.exit(1);
}
if (!existsSync("android")) run("npx cap add android");
run("npx cap sync android");
const gradle = process.platform === "win32" ? "gradlew.bat" : "./gradlew";
run(`${gradle} bundleRelease`, "android");
const out = "android/app/build/outputs/bundle/release/app-release.aab";
if (!existsSync(out)) { console.error("AAB not found at " + out); process.exit(1); }
mkdirSync("dist", { recursive: true });
copyFileSync(out, "dist/lastseat.aab");
console.log("\nDone: dist/lastseat.aab (sign with your upload key; see README)");
