# LastSeat

```bash
npm install
cp .env.example .env.local   # all keys optional: no keys = mock flights + simulated payment
npm run dev
```
1. Run `supabase/schema.sql` in your Supabase SQL editor; add the three Supabase env vars.
2. Duffel: `DUFFEL_API_KEY=duffel_test_...` for sandbox. Razorpay: use `rzp_test_` keys.
3. Admin: open `/admin`, enter `ADMIN_KEY` (`dev` locally if unset).

## Android (.aab)
Deploy the site first, set `CAP_SERVER_URL`, then:
```bash
npm run android:init                 # once
# add an upload keystore + signingConfigs.release in android/app/build.gradle
npm run build:android                # -> android/app/build/outputs/bundle/release/app-release.aab
```
Requires JDK 17 and Android SDK. Add `public/` icons via `@capacitor/assets` for launcher icons.

## Known gaps before launch
- Duffel doesn't expose seats remaining: `seatsLeft` is derived in `lib/duffel.ts`. Sandbox fares may not be in INR.
- Payment records a booking but doesn't create a Duffel order (ticketing) yet.
- Supabase Auth UI isn't built; bookings are guest bookings (`user_id` null). Push sends are logged until FCM is wired.
- Custom offers are saved but not yet applied to deal pricing.
