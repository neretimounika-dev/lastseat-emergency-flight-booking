export const metadata = { title: "Terms of Service — LastSeat" };
export default function Terms() {
  return (
    <article className="space-y-3 text-sm leading-relaxed">
      <h1 className="text-2xl font-bold">Terms of Service</h1><p>Last updated: October 2026</p>
      <h2 className="font-bold">Service</h2>
      <p>LastSeat lists discounted seats on flights departing within 12 hours. Availability and fares change in real time and are confirmed only when payment succeeds and a PNR is issued.</p>
      <h2 className="font-bold">Pricing and discounts</h2>
      <p>Flights departing in under 6 hours show 40% off; under 3 hours show 60% off. Discounts apply to the base fare shown and may change as departure approaches.</p>
      <h2 className="font-bold">Your responsibilities</h2>
      <p>Enter passenger names exactly as on a valid government photo ID, and arrive at the airport in time for check-in. Missed flights caused by late arrival are not refundable.</p>
      <h2 className="font-bold">Cancellations and refunds</h2>
      <p>Emergency fares are non-refundable and non-changeable unless the airline cancels or materially reschedules the flight, in which case you may request a refund.</p>
      <h2 className="font-bold">Liability and governing law</h2>
      <p>We act as an intermediary; the airline is responsible for carriage. Our liability is limited to the fare paid, to the extent permitted by law. These terms are governed by the laws of India.</p>
      <p className="text-xs text-slate-500">Have this reviewed by counsel before publishing.</p>
    </article>
  );
}
