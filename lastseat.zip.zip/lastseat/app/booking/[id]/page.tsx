"use client";
import Script from "next/script";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Trust } from "@/components/trust";
import { Flight, badge, finalPrice, hoursLeft } from "@/lib/deals";
import { inr } from "@/lib/utils";

declare global { interface Window { Razorpay: any } }

export default function Booking() {
  const { id } = useParams<{ id: string }>(); const router = useRouter();
  const [f, setF] = useState<Flight | null>(null);
  const [p, setP] = useState({ name: "", email: "", phone: "" });
  const [busy, setBusy] = useState(false); const [err, setErr] = useState("");

  useEffect(() => {
    // The flight is looked up again from the list of live deals
    fetch(`/api/flights?origin=${decodeURIComponent(id).slice(0, 3)}`).then((r) => r.json())
      .then((d) => { const x = (d.flights as Flight[]).find((y) => y.id === decodeURIComponent(id)); x ? setF(x) : setErr("This flight is no longer available."); })
      .catch(() => setErr("Couldn't load this flight."));
  }, [id]);

  async function finish(body: object) {
    const r = await fetch("/api/payment", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ flightId: f!.id, passenger: p, ...body }) });
    const d = await r.json(); if (!r.ok) throw new Error(d.error);
    sessionStorage.setItem("lastseat:ticket", JSON.stringify({ ...d, passenger: p }));
    router.push(`/success?pnr=${d.pnr}`);
  }

  async function pay() {
    if (!p.name || !/^\S+@\S+\.\S+$/.test(p.email) || p.phone.length < 10) return setErr("Enter your name, a valid email and a 10-digit phone number.");
    setBusy(true); setErr("");
    try {
      const r = await fetch("/api/payment", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ flightId: f!.id }) });
      const o = await r.json(); if (!r.ok) throw new Error(o.error);
      if (o.mock) return await finish({ orderId: o.orderId }); // test mode, no Razorpay keys set
      new window.Razorpay({ key: o.keyId, amount: o.amount * 100, currency: "INR", order_id: o.orderId, name: "LastSeat",
        description: `${f!.from} → ${f!.to}`, prefill: { name: p.name, email: p.email, contact: p.phone }, theme: { color: "#3B82F6" },
        handler: (x: any) => finish({ orderId: x.razorpay_order_id, paymentId: x.razorpay_payment_id, signature: x.razorpay_signature }).catch((e) => { setErr(e.message); setBusy(false); }),
        modal: { ondismiss: () => setBusy(false) } }).open();
    } catch (e: any) { setErr(e.message || "Payment failed"); setBusy(false); }
  }

  if (!f) return <p className={err ? "text-emergency" : "text-slate-500"}>{err || "Loading flight…"}</p>;
  const h = hoursLeft(f.departure), b = badge(h), price = finalPrice(f.basePrice, h);
  return (
    <div className="space-y-4">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />
      <Card>
        <p className="text-xl font-bold">{f.from} → {f.to}</p>
        <p className="text-sm text-slate-500">{f.airline} · {f.flightNo} · {new Date(f.departure).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" })}</p>
        <p className="mt-3 text-2xl font-extrabold">{inr(price)} {b && <span className="text-sm font-semibold text-emergency">{b.label}</span>}</p>
      </Card>
      <Card className="space-y-3">
        <h2 className="font-bold">Passenger details</h2>
        <Input placeholder="Full name (as on ID)" autoComplete="name" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
        <Input placeholder="Email" type="email" autoComplete="email" value={p.email} onChange={(e) => setP({ ...p, email: e.target.value })} />
        <Input placeholder="Phone" type="tel" autoComplete="tel" value={p.phone} onChange={(e) => setP({ ...p, phone: e.target.value.replace(/\D/g, "") })} />
        {err && <p role="alert" className="text-sm text-emergency">{err}</p>}
        <Button className="w-full" variant={b?.emergency ? "danger" : "default"} disabled={busy} onClick={pay}>{busy ? "Processing…" : `Pay ${inr(price)}`}</Button>
      </Card>
      <div className="rounded-xl bg-ink p-4"><Trust /></div>
    </div>
  );
}
