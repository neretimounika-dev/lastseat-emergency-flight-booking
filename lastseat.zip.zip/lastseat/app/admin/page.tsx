"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { inr } from "@/lib/utils";

export default function Admin() {
  const [key, setKey] = useState(""); const [s, setS] = useState<any>(null); const [msg, setMsg] = useState("");
  const [o, setO] = useState({ title: "", route: "", pct: "" }); const [n, setN] = useState({ title: "", body: "" });
  const call = async (method: string, body?: object) => {
    const r = await fetch("/api/admin", { method, headers: { "x-admin-key": key, "Content-Type": "application/json" }, body: body && JSON.stringify(body) });
    const d = await r.json(); if (!r.ok) throw new Error(d.error); return d;
  };
  const load = () => call("GET").then(setS).catch((e) => setMsg(e.message));
  const send = (b: object) => call("POST", b).then((d) => setMsg(d.note || "Saved")).catch((e) => setMsg(e.message));

  if (!s) return (
    <Card className="space-y-3"><h1 className="font-bold">Admin sign-in</h1>
      <Input type="password" placeholder="Admin key" value={key} onChange={(e) => setKey(e.target.value)} />
      <Button onClick={load}>Open dashboard</Button>{msg && <p className="text-sm text-emergency">{msg}</p>}</Card>
  );
  return (
    <div className="space-y-4">
      {!s.configured && <p className="rounded-lg bg-amber-100 p-3 text-sm">Supabase isn't configured, so stats are empty.</p>}
      <div className="grid grid-cols-2 gap-3">
        <Card><p className="text-sm text-slate-500">Total bookings</p><p className="text-3xl font-extrabold">{s.bookings}</p></Card>
        <Card><p className="text-sm text-slate-500">Revenue</p><p className="text-3xl font-extrabold">{inr(s.revenue)}</p></Card>
      </div>
      <Card className="space-y-3"><h2 className="font-bold">Add custom offer</h2>
        <Input placeholder="Title" value={o.title} onChange={(e) => setO({ ...o, title: e.target.value })} />
        <Input placeholder="Route (e.g. HYD-BLR, optional)" value={o.route} onChange={(e) => setO({ ...o, route: e.target.value })} />
        <Input placeholder="Discount %" type="number" value={o.pct} onChange={(e) => setO({ ...o, pct: e.target.value })} />
        <Button onClick={() => send({ type: "offer", ...o })}>Save offer</Button></Card>
      <Card className="space-y-3"><h2 className="font-bold">Send push notification</h2>
        <Input placeholder="Title" value={n.title} onChange={(e) => setN({ ...n, title: e.target.value })} />
        <Input placeholder="Message" value={n.body} onChange={(e) => setN({ ...n, body: e.target.value })} />
        <Button onClick={() => send({ type: "push", ...n })}>Send push</Button></Card>
      {msg && <p className="text-sm">{msg}</p>}
      <Card><h2 className="mb-2 font-bold">Recent bookings</h2>
        {s.recent.map((r: any) => <p key={r.pnr} className="flex justify-between border-t py-2 text-sm"><span>{r.pnr} · {r.origin}→{r.destination} · {r.passenger_name}</span><b>{inr(r.amount_inr)}</b></p>)}
        {!s.recent.length && <p className="text-sm text-slate-500">No bookings yet.</p>}</Card>
    </div>
  );
}
