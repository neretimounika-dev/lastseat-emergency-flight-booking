import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import Link from "next/link";
import "./globals.css";
import { PWA } from "@/components/pwa";

const inter = Inter({ subsets: ["latin"] });
export const metadata: Metadata = {
  title: "LastSeat — Emergency flight deals", description: "Up to 60% off empty seats on flights leaving in the next 12 hours.",
  manifest: "/manifest.json", appleWebApp: { capable: true, title: "LastSeat" }, icons: { apple: "/icon-192.png" },
};
export const viewport: Viewport = { themeColor: "#0F172A", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-ink text-white">
          <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4">
            <Link href="/" className="text-lg font-extrabold">Last<span className="text-accent">Seat</span></Link>
            <nav className="flex gap-4 text-sm text-slate-300"><Link href="/deals">Deals</Link><Link href="/admin">Admin</Link></nav>
          </div>
        </header>
        <main className="mx-auto min-h-[70vh] max-w-3xl px-4 py-6">{children}</main>
        <footer className="bg-ink py-6 text-center text-xs text-slate-400">
          <Link href="/privacy" className="mx-2">Privacy</Link><Link href="/terms" className="mx-2">Terms</Link>
          <p className="mt-2">© {new Date().getFullYear()} LastSeat</p>
        </footer>
        <PWA />
      </body>
    </html>
  );
}
