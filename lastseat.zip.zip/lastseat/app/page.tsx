import { SearchBox } from "@/components/search-box";
import { Trust } from "@/components/trust";
export default function Home() {
  return (
    <section className="-mx-4 -mt-6 bg-ink px-4 pb-10 pt-10">
      <h1 className="text-4xl font-extrabold leading-tight text-white sm:text-5xl">Need to fly in 4 hours? Get 60% OFF on empty seats</h1>
      <p className="mt-3 max-w-prose text-slate-300">Flights leaving in the next 12 hours, priced down as departure gets closer. Pick your city and book in one tap.</p>
      <div className="mt-6"><SearchBox /></div>
      <div className="mt-6"><Trust /></div>
    </section>
  );
}
