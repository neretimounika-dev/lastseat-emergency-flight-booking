export const metadata = { title: "Privacy Policy — LastSeat" };
export default function Privacy() {
  return (
    <article className="space-y-3 text-sm leading-relaxed">
      <h1 className="text-2xl font-bold">Privacy Policy</h1><p>Last updated: October 2026</p>
      <h2 className="font-bold">What we collect</h2>
      <p>Name, email and phone number you enter when booking; booking details (route, flight, fare, PNR); basic device and usage data; and, if you opt in, a push-notification token.</p>
      <h2 className="font-bold">How we use it</h2>
      <p>To issue and manage your booking, send confirmations and flight alerts, prevent fraud, and improve the app. We don't sell your personal data.</p>
      <h2 className="font-bold">Who we share it with</h2>
      <p>Airlines and our flight-data provider (Duffel) to fulfil your ticket; Razorpay to process payments (we never see or store your card details); Supabase, which hosts our database.</p>
      <h2 className="font-bold">Retention and your rights</h2>
      <p>We keep booking records as long as needed for service, tax and legal obligations. You can request access, correction or deletion of your data by writing to support@lastseat.example.com.</p>
      <h2 className="font-bold">Security and children</h2>
      <p>Data is encrypted in transit and access-controlled. LastSeat is not directed at children under 13.</p>
      <h2 className="font-bold">Contact</h2><p>support@lastseat.example.com</p>
      <p className="text-xs text-slate-500">Replace the contact details and have this reviewed by counsel before publishing.</p>
    </article>
  );
}
