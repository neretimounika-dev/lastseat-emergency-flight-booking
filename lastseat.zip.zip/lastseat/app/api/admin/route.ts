import { NextResponse } from "next/server";
import { serverClient } from "@/lib/supabase";
export const dynamic = "force-dynamic";

const adminKey = () => process.env.ADMIN_KEY || (process.env.NODE_ENV !== "production" ? "dev" : null);
const authed = (req: Request) => { const k = adminKey(); return !!k && req.headers.get("x-admin-key") === k; };

export async function GET(req: Request) {
  if (!authed(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const sb = serverClient();
  if (!sb) return NextResponse.json({ configured: false, bookings: 0, revenue: 0, recent: [] });
  const { data } = await sb.from("bookings").select("pnr,origin,destination,passenger_name,amount_inr,created_at").order("created_at", { ascending: false }).limit(200);
  const rows = data ?? [];
  return NextResponse.json({ configured: true, bookings: rows.length, revenue: rows.reduce((s, r) => s + r.amount_inr, 0), recent: rows.slice(0, 10) });
}

export async function POST(req: Request) {
  if (!authed(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const b = await req.json();
  const sb = serverClient();
  if (b.type === "offer") {
    if (!sb) return NextResponse.json({ error: "Supabase not configured" }, { status: 503 });
    const { error } = await sb.from("offers").insert({ title: b.title, route: b.route || null, discount_pct: Number(b.pct) });
    return error ? NextResponse.json({ error: error.message }, { status: 500 }) : NextResponse.json({ ok: true });
  }
  if (b.type === "push") {
    // Hook point: send through FCM (firebase-admin) once google-services.json is added to the Android project.
    console.log("[push]", b.title, b.body);
    return NextResponse.json({ ok: true, note: "Logged only — connect FCM to deliver." });
  }
  return NextResponse.json({ error: "Bad request" }, { status: 400 });
}
