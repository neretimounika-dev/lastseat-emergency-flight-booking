import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import { addOffer } from "@/lib/db";
import { ROUTES } from "@/lib/duffel";
export async function POST(req: NextRequest) {
  const denied = await requireAdmin(req); if (denied) return denied;
  const { origin, destination, percentOff, label, hours } = await req.json();
  const pct = Number(percentOff), h = Number(hours);
  if (!ROUTES[origin]?.includes(destination) || !(pct >= 1 && pct <= 90) || !(h > 0 && h <= 168))
    return NextResponse.json({ error: "Invalid offer" }, { status: 400 });
  await addOffer({ origin, destination, percent_off: pct, label: String(label || "Special offer").slice(0, 60), expires_at: new Date(Date.now() + h * 36e5).toISOString() });
  return NextResponse.json({ ok: true });
}
