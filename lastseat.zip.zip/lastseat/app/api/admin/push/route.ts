import { NextRequest, NextResponse } from "next/server";
import webpush from "web-push";
import { requireAdmin } from "@/lib/admin";
import { listSubs } from "@/lib/db";

export async function POST(req: NextRequest) {
  const denied = await requireAdmin(req); if (denied) return denied;
  const { title, body, url } = await req.json();
  if (!title || !body) return NextResponse.json({ error: "Title and message are required" }, { status: 400 });
  const pub = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY, priv = process.env.VAPID_PRIVATE_KEY;
  if (!pub || !priv) return NextResponse.json({ error: "Set VAPID keys to send push (npx web-push generate-vapid-keys)" }, { status: 503 });
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || "mailto:support@lastseat.app", pub, priv);
  const subs = await listSubs();
  const payload = JSON.stringify({ title, body, url: url || "/deals" });
  const res = await Promise.allSettled(subs.map((s) => webpush.sendNotification(s, payload)));
  return NextResponse.json({ sent: res.filter((r) => r.status === "fulfilled").length, total: subs.length });
}
