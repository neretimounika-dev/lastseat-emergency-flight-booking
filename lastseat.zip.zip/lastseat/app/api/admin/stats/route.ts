import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin";
import { bookingStats, activeOffers } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET(req: NextRequest) {
  const denied = await requireAdmin(req); if (denied) return denied;
  return NextResponse.json({ ...(await bookingStats()), offers: await activeOffers() });
}
