import { NextResponse } from "next/server";
import { getEmergencyFlights } from "@/lib/duffel";
import { ORIGINS } from "@/lib/deals";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const o = new URL(req.url).searchParams.get("origin") || "HYD";
  if (!(ORIGINS as readonly string[]).includes(o)) return NextResponse.json({ error: "Unknown origin" }, { status: 400 });
  return NextResponse.json({ flights: await getEmergencyFlights(o) });
}
