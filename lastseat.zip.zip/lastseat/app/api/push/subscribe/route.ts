import { NextRequest, NextResponse } from "next/server";
import { saveSub } from "@/lib/db";
export async function POST(req: NextRequest) {
  const sub = await req.json();
  if (!sub?.endpoint) return NextResponse.json({ error: "Invalid subscription" }, { status: 400 });
  await saveSub(sub);
  return NextResponse.json({ ok: true });
}
