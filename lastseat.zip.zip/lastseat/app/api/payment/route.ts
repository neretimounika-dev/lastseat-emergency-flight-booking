import { NextResponse } from "next/server";
import crypto from "crypto";
import Razorpay from "razorpay";
import { getFlight } from "@/lib/duffel";
import { badge, finalPrice, hoursLeft } from "@/lib/deals";
import { serverClient } from "@/lib/supabase";
export const dynamic = "force-dynamic";

const KEY_ID = process.env.RAZORPAY_KEY_ID, KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
const live = !!(KEY_ID && KEY_SECRET); // no keys => simulated test mode

async function priced(flightId: string) {
  const f = await getFlight(flightId);
  if (!f) return null;
  const h = hoursLeft(f.departure);
  if (h <= 0) return null;
  return { f, amount: finalPrice(f.basePrice, h), pct: badge(h)?.pct ?? 0 }; // price always recomputed server-side
}

// Create order
export async function POST(req: Request) {
  const { flightId } = await req.json();
  const p = await priced(flightId);
  if (!p) return NextResponse.json({ error: "Flight unavailable" }, { status: 410 });
  if (!live) return NextResponse.json({ mock: true, amount: p.amount, orderId: `order_mock_${Date.now()}` });
  const rz = new Razorpay({ key_id: KEY_ID!, key_secret: KEY_SECRET! });
  const order = await rz.orders.create({ amount: p.amount * 100, currency: "INR", receipt: `ls_${Date.now()}` });
  return NextResponse.json({ orderId: order.id, amount: p.amount, keyId: KEY_ID });
}

// Verify payment, issue PNR, save booking
export async function PUT(req: Request) {
  const { flightId, orderId, paymentId, signature, passenger } = await req.json();
  if (live) {
    const expected = crypto.createHmac("sha256", KEY_SECRET!).update(`${orderId}|${paymentId}`).digest("hex");
    if (expected !== signature) return NextResponse.json({ error: "Payment verification failed" }, { status: 400 });
  }
  const p = await priced(flightId);
  if (!p && live) return NextResponse.json({ error: "Flight unavailable" }, { status: 410 });
  const f = p?.f ?? (await getFlight(flightId))!;
  const pnr = crypto.randomBytes(4).toString("hex").slice(0, 6).toUpperCase();
  const sb = serverClient();
  if (sb) {
    const { error } = await sb.from("bookings").insert({ pnr, flight_id: f.id, origin: f.from, destination: f.to, flight_no: f.flightNo,
      departure: f.departure, passenger_name: passenger.name, passenger_email: passenger.email, passenger_phone: passenger.phone,
      amount_inr: p?.amount ?? f.basePrice, discount_pct: p?.pct ?? 0, razorpay_order_id: orderId, razorpay_payment_id: paymentId ?? null });
    if (error) { console.error(error); return NextResponse.json({ error: "Could not save booking" }, { status: 500 }); }
  }
  return NextResponse.json({ pnr, flight: f, amount: p?.amount ?? f.basePrice });
}
