import { NextRequest, NextResponse } from "next/server";
import { getBooking } from "@/lib/db";

export async function GET(req: NextRequest) {
  const pnr = (req.nextUrl.searchParams.get("pnr") || "").toUpperCase();
  const b = pnr.length === 6 ? await getBooking(pnr) : null;
  if (!b) return NextResponse.json({ error: "Booking not found" }, { status: 404 });
  const { email, phone, razorpay_order_id, razorpay_payment_id, user_id, ...safe } = b; // no PII from PNR alone
  return NextResponse.json({ booking: safe });
}
