"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { inr } from "@/lib/utils";

export default function Success() {
  const [t, setT] = useState<any>(null);
  useEffect(() => { try { setT(JSON.parse(sessionStorage.getItem("lastseat:ticket") || "null")); } catch {} }, []);
  if (!t) return <p className="text-slate-500">No ticket found. <Link className="text-accent underline" href="/deals">Browse deals</Link></p>;
  return (
    <Card className="space-y-3">
      <p className="font-semibold text-green-600">Booking confirmed</p>
      <p className="text-sm text-slate-500">Your PNR</p>
      <p className="text-4xl font-extrabold tracking-widest">{t.pnr}</p>
      <hr />
      <p className="text-lg font-bold">{t.flight.from} → {t.flight.to}</p>
      <p className="text-sm text-slate-600">{t.flight.airline} {t.flight.flightNo} · {new Date(t.flight.departure).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" })}</p>
      <p className="text-sm">Passenger: <b>{t.passenger.name}</b></p>
      <p className="text-sm">Paid: <b>{inr(t.amount)}</b></p>
      <p className="text-xs text-slate-500">Reach the airport at least 90 minutes before departure with a valid photo ID.</p>
      <Link href="/deals" className="text-sm text-accent underline">Find another flight</Link>
    </Card>
  );
}
