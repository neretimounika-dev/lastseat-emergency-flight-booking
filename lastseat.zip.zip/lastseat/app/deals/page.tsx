"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { FlightCard } from "@/components/flight-card";
import { SearchBox } from "@/components/search-box";
import { Flight } from "@/lib/deals";

function Deals() {
  const origin = useSearchParams().get("origin") || "HYD";
  const [flights, setFlights] = useState<Flight[] | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    let live = true;
    const load = () => fetch(`/api/flights?origin=${origin}`).then((r) => r.json())
      .then((d) => live && (setFlights(d.flights ?? []), setErr(""))).catch(() => live && setErr("Couldn't load flights. Check your connection and retry."));
    setFlights(null); load();
    const i = setInterval(load, 60_000); // re-prices badges as departure nears
    return () => { live = false; clearInterval(i); };
  }, [origin]);

  return (
    <div className="space-y-4">
      <SearchBox initial={origin} />
      <h1 className="text-xl font-bold">Flights from {origin} in the next 12 hours</h1>
      {err && <p className="text-emergency">{err}</p>}
      {!flights && !err && <p className="text-slate-500">Finding empty seats…</p>}
      {flights?.length === 0 && <p className="text-slate-500">No deals leaving {origin} right now. Check back soon or try another city.</p>}
      {flights?.map((f) => <FlightCard key={f.id} f={f} />)}
    </div>
  );
}
export default function Page() { return <Suspense><Deals /></Suspense>; }
