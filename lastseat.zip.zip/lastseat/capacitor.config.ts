import type { CapacitorConfig } from "@capacitor/cli";

// Flights, payments and the admin API need a server, so the Android app wraps the
// deployed Next.js site (set CAP_SERVER_URL to your production URL) instead of a static export.
const config: CapacitorConfig = {
  appId: "in.lastseat.app",
  appName: "LastSeat",
  webDir: "public",
  server: { url: process.env.CAP_SERVER_URL || "https://lastseat.example.com", cleartext: false },
  android: { buildOptions: { releaseType: "AAB" } },
};
export default config;
