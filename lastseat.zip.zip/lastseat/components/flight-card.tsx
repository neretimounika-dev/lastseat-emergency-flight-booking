import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Countdown } from "@/components/countdown";
import { Flight, badge, finalPrice, hoursLeft } from "@/lib/deals";
import { cn, inr } from "@/lib/utils";

export function FlightCard({ f }: { f: Flight }) {
  const h = hoursLeft(f.departure), b = badge(h), price = finalPrice(f.basePrice, h);
  const time = new Date(f.departure).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Kolkata" });
  return (
    <Card className={cn(b?.emergency && "border-emergency/60 ring-1 ring-emergency/30")}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xl font-bold text-ink">{f.from} → {f.to}</p>
          <p className="text-sm text-slate-500">{f.airline} · {f.flightNo} · departs {time}</p>
        </div>
        {b && <Badge className={b.emergency ? "bg-emergency" : ""}>{b.label}</Badge>}
      </div>
      <div className="mt-4 flex items-end justify-between">
        <div>
          <p className="text-2xl font-extrabold text-ink">{inr(price)}</p>
          {b && <p className="text-sm text-slate-400 line-through">{inr(f.basePrice)}</p>}
        </div>
        <div className="text-right text-sm">
          <p className={cn("font-semibold", b?.emergency ? "text-emergency" : "text-ink")}>Departs in <Countdown to={f.departure} /></p>
          <p className="text-slate-500">{f.seatsLeft} seats left</p>
        </div>
      </div>
      <Link href={`/booking/${f.id}`} className={cn("mt-4 flex h-11 items-center justify-center rounded-lg text-sm font-semibold text-white", b?.emergency ? "bg-emergency hover:bg-red-700" : "bg-accent hover:bg-blue-600")}>
        Book now
      </Link>
    </Card>
  );
}
