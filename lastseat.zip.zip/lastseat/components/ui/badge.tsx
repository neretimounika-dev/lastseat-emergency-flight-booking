import { cn } from "@/lib/utils";
export const Badge = ({ className, ...p }: React.HTMLAttributes<HTMLSpanElement>) =>
  <span className={cn("inline-block rounded-md bg-accent px-2 py-1 text-xs font-bold text-white", className)} {...p} />;
