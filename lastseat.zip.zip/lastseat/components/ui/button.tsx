import * as React from "react";
import { cn } from "@/lib/utils";
type P = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "default" | "danger" | "outline" };
export const Button = React.forwardRef<HTMLButtonElement, P>(({ className, variant = "default", ...p }, ref) => (
  <button ref={ref} className={cn(
    "inline-flex h-11 items-center justify-center rounded-lg px-5 text-sm font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50",
    variant === "default" && "bg-accent text-white hover:bg-blue-600",
    variant === "danger" && "bg-emergency text-white hover:bg-red-700",
    variant === "outline" && "border border-slate-300 bg-white text-ink hover:bg-slate-50", className)} {...p} />
));
Button.displayName = "Button";
