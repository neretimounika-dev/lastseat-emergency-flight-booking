export function Legal({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <article className="mx-auto max-w-2xl space-y-4 px-4 py-8 text-sm leading-relaxed text-slate-700 [&_h2]:mt-6 [&_h2]:text-lg [&_h2]:font-bold [&_h2]:text-slate-900 [&_ul]:list-disc [&_ul]:pl-5">
      <h1 className="text-2xl font-extrabold text-slate-900">{title}</h1>
      <p className="text-slate-500">Last updated: {updated}</p>
      {children}
    </article>
  );
}
