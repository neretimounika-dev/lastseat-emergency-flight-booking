const ITEMS = ["Secure payments by Razorpay", "Instant PNR confirmation", "Real airline inventory", "24×7 support"];
export function Trust() {
  return (
    <ul className="flex flex-wrap gap-x-5 gap-y-2 text-xs text-slate-300">
      {ITEMS.map((t) => <li key={t} className="flex items-center gap-1.5"><span aria-hidden className="text-green-400">✓</span>{t}</li>)}
    </ul>
  );
}
