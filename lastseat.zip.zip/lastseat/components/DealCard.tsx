"use client";
import Link from "next/link";
import { Clock, Armchair, ArrowRight } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Countdown } from "@/components/Countdown";
import { discountFor, finalPrice, hoursUntil, isEmergency } from "@/lib/pricing";
import { inr, timeOf, cn } from "@/lib/utils";
import { AIRPORTS } from "@/lib/airports";

export type Deal = { id: string; origin: string; destination: string; airline: string; flightNo: string; departsAt: string; arrivesAt: string; basePrice: number; seatsLeft: number; offerPct: number };

export function DealCard({ f, now }: { f: Deal; now: number }) {
  const h = hoursUntil(f.departsAt, now), pct = discountFor(h, f.offerPct), hot = isEmergency(h) || pct >= 60;
  return (
    <Card className={cn("overflow-hidden", hot && "border-emergency/40 ring-1 ring-emergency/30")}>
      <div className={cn("flex items-center justify-between px-4 py-2 text-sm font-semibold", hot ? "bg-emergency text-white" : "bg-navy text-white")}>
        <span className="flex items-center gap-1.5"><Clock size={15} />Departs in <Countdown to={f.departsAt} className="tabular-nums" /></span>
        {pct > 0 && <Badge variant={hot ? "default" : "emergency"} className={hot ? "bg-white text-emergency" : "bg-accent"}>{pct}% OFF{pct >= 60 ? " Emergency" : ""}</Badge>}
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div><p className="text-2xl font-extrabold">{f.origin}</p><p className="text-xs text-slate-500">{timeOf(f.departsAt)}</p></div>
          <div className="flex-1 px-3 text-center text-xs text-slate-500"><ArrowRight className="mx-auto text-slate-400" size={18} />{f.airline} · {f.flightNo}</div>
          <div className="text-right"><p className="text-2xl font-extrabold">{f.destination}</p><p className="text-xs text-slate-500">{timeOf(f.arrivesAt)}</p></div>
        </div>
        <p className="mt-1 text-center text-xs text-slate-400">{AIRPORTS[f.origin]} to {AIRPORTS[f.destination]}</p>
        <div className="mt-4 flex items-end justify-between">
          <div>
            {pct > 0 && <p className="text-sm text-slate-400 line-through">{inr(f.basePrice)}</p>}
            <p className="text-3xl font-extrabold text-navy">{inr(finalPrice(f.basePrice, pct))}</p>
            <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-emergency"><Armchair size={14} />{f.seatsLeft} seats left</p>
          </div>
          <Button asChild variant={hot ? "emergency" : "default"} size="lg"><Link href={`/booking/${encodeURIComponent(f.id)}`}>Book now</Link></Button>
        </div>
      </div>
    </Card>
  );
}
