"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CITY, ORIGINS } from "@/lib/deals";
export function SearchBox({ initial = "HYD" }: { initial?: string }) {
  const r = useRouter(); const [o, setO] = useState(initial);
  return (
    <div className="flex flex-col gap-3 rounded-xl bg-white p-4 shadow-lg sm:flex-row sm:items-end">
      <label className="flex-1 text-sm font-medium text-ink">Flying from
        <select value={o} onChange={(e) => setO(e.target.value)} className="mt-1 h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-base">
          {ORIGINS.map((c) => <option key={c} value={c}>{CITY[c]} ({c})</option>)}
        </select>
      </label>
      <Button onClick={() => r.push(`/deals?origin=${o}`)}>Find flights in the next 12 hours</Button>
    </div>
  );
}
