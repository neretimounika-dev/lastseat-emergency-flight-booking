"use client";
import { useState } from "react";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
const b64 = (s: string) => { const p = "=".repeat((4 - (s.length % 4)) % 4), r = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(r, (c) => c.charCodeAt(0)); };

export function PushOptIn() {
  const [state, setState] = useState<"idle" | "on" | "blocked">("idle");
  const key = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  if (!key || typeof window === "undefined" || !("PushManager" in window)) return null;
  async function enable() {
    if ((await Notification.requestPermission()) !== "granted") return setState("blocked");
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64(key!) });
    await fetch("/api/push/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub) });
    setState("on");
  }
  return (
    <Button variant="outline" size="sm" onClick={enable} disabled={state !== "idle"}>
      <Bell size={15} />{state === "on" ? "Alerts on" : state === "blocked" ? "Alerts blocked in browser" : "Alert me to new deals"}
    </Button>
  );
}
