import Link from "next/link";
import { Plane } from "lucide-react";
export function Header() {
  return (
    <header className="sticky top-0 z-30 bg-navy text-white">
      <div className="mx-auto flex h-14 max-w-3xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 text-lg font-extrabold tracking-tight">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-accent"><Plane size={18} /></span>LastSeat
        </Link>
        <nav className="flex gap-4 text-sm text-slate-300">
          <Link href="/deals" className="hover:text-white">Deals</Link>
          <Link href="/admin" className="hover:text-white">Admin</Link>
        </nav>
      </div>
    </header>
  );
}
export function Footer() {
  return (
    <footer className="mx-auto max-w-3xl px-4 py-8 text-center text-xs text-slate-500">
      <p>© {new Date().getFullYear()} LastSeat · <Link href="/privacy" className="underline">Privacy</Link> · <Link href="/terms" className="underline">Terms</Link></p>
    </footer>
  );
}
