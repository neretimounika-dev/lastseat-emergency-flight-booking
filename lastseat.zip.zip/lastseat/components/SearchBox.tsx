"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AIRPORTS } from "@/lib/airports";
import { Label } from "@/components/ui/input";

export function SearchBox({ initial = "HYD" }: { initial?: string }) {
  const router = useRouter();
  const [origin, setOrigin] = useState(initial);
  return (
    <div className="rounded-xl bg-white p-4 text-slate-900 shadow-lg">
      <Label htmlFor="origin">Flying from</Label>
      <select id="origin" value={origin} onChange={(e) => setOrigin(e.target.value)} className="mb-3 h-12 w-full rounded-lg border border-slate-300 bg-white px-3 text-base font-medium">
        {Object.entries(AIRPORTS).map(([c, n]) => <option key={c} value={c}>{n} ({c})</option>)}
      </select>
      <Button size="lg" className="w-full" onClick={() => router.push(`/deals?origin=${origin}`)}><Search size={18} />Find flights in next 12 hours</Button>
    </div>
  );
}
