"use client";
import { useEffect, useState } from "react";
const p = (n: number) => String(n).padStart(2, "0");
export function Countdown({ to }: { to: string }) {
  const [t, setT] = useState(0);
  useEffect(() => { const f = () => setT(Math.max(0, new Date(to).getTime() - Date.now())); f(); const i = setInterval(f, 1000); return () => clearInterval(i); }, [to]);
  return <span className="tabular-nums">{p(Math.floor(t / 36e5))}:{p(Math.floor((t % 36e5) / 6e4))}:{p(Math.floor((t % 6e4) / 1e3))}</span>;
}
