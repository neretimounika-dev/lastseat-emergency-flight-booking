import { ShieldCheck, BadgeCheck, Lock, Headphones } from "lucide-react";
const items = [
  { Icon: ShieldCheck, t: "Secure payments", d: "Razorpay encrypted" },
  { Icon: BadgeCheck, t: "Real airlines", d: "Confirmed seats" },
  { Icon: Lock, t: "Data protected", d: "We never sell it" },
  { Icon: Headphones, t: "24x7 help", d: "Before you fly" },
];
export function TrustBadges() {
  return (
    <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {items.map(({ Icon, t, d }) => (
        <li key={t} className="flex items-center gap-2 rounded-lg bg-white p-3 text-xs shadow-sm">
          <Icon className="shrink-0 text-accent" size={20} />
          <span><b className="block text-slate-800">{t}</b><span className="text-slate-500">{d}</span></span>
        </li>
      ))}
    </ul>
  );
}
