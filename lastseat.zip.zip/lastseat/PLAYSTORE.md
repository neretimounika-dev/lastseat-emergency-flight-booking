# LastSeat — Play Store listing

**App name:** LastSeat: Last-Minute Flights (≤30 chars)

**Short description (≤80 chars):**
Up to 60% off empty seats on flights leaving in the next 12 hours.

**Full description:**
Need to fly today? LastSeat shows flights departing in the next 12 hours and cuts the price as takeoff gets closer.

• 40% OFF on flights leaving in under 6 hours
• 60% OFF Emergency deals on flights leaving in under 3 hours
• Live countdown on every flight so you know how long you have
• Only flights with plenty of seats left, so you can book with confidence
• Choose your city (Hyderabad, Bengaluru, Delhi, Chennai) and see deals instantly
• One-tap booking, secure Razorpay payment, and instant PNR confirmation
• Push alerts when new emergency deals appear

How it works: pick where you're flying from, choose a flight, enter passenger details, pay, and get your PNR. No sign-up required to browse.

Fares are non-refundable unless the airline cancels or reschedules. Enter names exactly as on your government ID.

**Keywords / tags:** last minute flights, emergency flights, cheap flights today, flight deals, same day flight, urgent flight booking, flight discount, Hyderabad flights, Bangalore flights, Delhi flights, Chennai flights, book flight now

**Category:** Travel & Local · **Content rating:** Everyone · **Privacy policy URL:** https://YOUR-DOMAIN/privacy · **Terms:** https://YOUR-DOMAIN/terms

**Data safety form:** collects name, email, phone, purchase history, device identifiers (push token); data encrypted in transit; deletion on request.
