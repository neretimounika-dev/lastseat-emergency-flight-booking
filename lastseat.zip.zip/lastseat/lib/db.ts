// Server-only data layer. Supabase when configured, in-memory demo store otherwise.
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL, svc = process.env.SUPABASE_SERVICE_ROLE_KEY;
export const hasDb = !!(url && svc);
export const sb = hasDb ? createClient(url!, svc!, { auth: { persistSession: false } }) : null;
const g = globalThis as any;
g.__lastseat ??= { bookings: [], offers: [], subs: [] };
const mem = g.__lastseat as { bookings: Booking[]; offers: Offer[]; subs: any[] };

export type Booking = {
  pnr: string; user_id?: string | null; flight_id: string; origin: string; destination: string; airline: string; flight_no: string;
  departs_at: string; passenger_name: string; email: string; phone: string; amount: number; discount_pct: number;
  razorpay_order_id: string; razorpay_payment_id: string; status: string; created_at?: string;
};
export type Offer = { id?: string; origin: string; destination: string; percent_off: number; label: string; expires_at: string };

export async function insertBooking(b: Booking) {
  if (sb) { const { error } = await sb.from("bookings").insert(b); if (error) throw error; }
  else mem.bookings.push({ ...b, created_at: new Date().toISOString() });
}
export async function getBooking(pnr: string): Promise<Booking | null> {
  if (sb) { const { data } = await sb.from("bookings").select("*").eq("pnr", pnr).maybeSingle(); return data; }
  return mem.bookings.find((b) => b.pnr === pnr) ?? null;
}
export async function bookingStats() {
  const rows: Booking[] = sb ? ((await sb.from("bookings").select("*").order("created_at", { ascending: false }).limit(500)).data ?? []) : mem.bookings;
  return { total: rows.length, revenue: rows.reduce((s, b) => s + Number(b.amount), 0), recent: rows.slice(0, 8).reverse().reverse() };
}
export async function addOffer(o: Offer) { if (sb) { const { error } = await sb.from("offers").insert(o); if (error) throw error; } else mem.offers.push(o); }
export async function activeOffers(): Promise<Offer[]> {
  const now = new Date().toISOString();
  if (sb) return (await sb.from("offers").select("*").gt("expires_at", now)).data ?? [];
  return mem.offers.filter((o) => o.expires_at > now);
}
export async function offerPct(origin: string, destination: string) {
  return (await activeOffers()).filter((o) => o.origin === origin && o.destination === destination).reduce((m, o) => Math.max(m, o.percent_off), 0);
}
export async function saveSub(sub: any) {
  if (sb) await sb.from("push_subscriptions").upsert({ endpoint: sub.endpoint, subscription: sub }, { onConflict: "endpoint" });
  else if (!mem.subs.find((s) => s.endpoint === sub.endpoint)) mem.subs.push(sub);
}
export async function listSubs(): Promise<any[]> {
  if (sb) return ((await sb.from("push_subscriptions").select("subscription")).data ?? []).map((r: any) => r.subscription);
  return mem.subs;
}
export const makePnr = () => Array.from({ length: 6 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[Math.floor(Math.random() * 32)]).join("");
