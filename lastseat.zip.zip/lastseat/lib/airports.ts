export const AIRPORTS: Record<string, string> = { HYD: "Hyderabad", BLR: "Bengaluru", DEL: "Delhi", MAA: "Chennai" };
export const ROUTE_LIST = ["HYD-BLR", "HYD-DEL", "HYD-MAA", "BLR-HYD", "DEL-HYD", "MAA-HYD"];
