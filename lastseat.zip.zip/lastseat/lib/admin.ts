import { NextRequest, NextResponse } from "next/server";
import { sb } from "./db";

/** Returns a NextResponse (401/403) if the caller isn't an admin, otherwise null. */
export async function requireAdmin(req: NextRequest) {
  if (!sb) return process.env.NODE_ENV === "production" ? NextResponse.json({ error: "Supabase not configured" }, { status: 503 }) : null;
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data } = await sb.auth.getUser(token);
  const admins = (process.env.ADMIN_EMAILS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (!data.user?.email || !admins.includes(data.user.email.toLowerCase())) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return null;
}
