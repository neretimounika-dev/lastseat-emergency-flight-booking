import { Flight, ORIGINS, hoursLeft } from "./deals";

const KEY = process.env.DUFFEL_API_KEY; // duffel_test_... = sandbox
const BASE = "https://api.duffel.com";
const headers = () => ({ Authorization: `Bearer ${KEY}`, "Duffel-Version": "v2", "Content-Type": "application/json", Accept: "application/json" });

const hash = (s: string) => { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
const AIRLINES = ["IndiGo", "Air India", "Akasa Air", "SpiceJet", "Vistara"];
const CODES = ["6E", "AI", "QP", "SG", "UK"];

/* ---------- Mock data: deterministic per departure slot so /deals and /booking/[id] agree ---------- */
function mockFlight(from: string, to: string, epochMin: number): Flight {
  const id = `${from}-${to}-${epochMin}`, h = hash(id), a = h % AIRLINES.length;
  return { id, from, to, airline: AIRLINES[a], flightNo: `${CODES[a]}${100 + (h % 900)}`,
    departure: new Date(epochMin * 6e4).toISOString(), basePrice: 3500 + (h % 5500), seatsLeft: 4 + (h % 37) };
}
function mockFlights(origin: string): Flight[] {
  const slot = 30, now = Math.floor(Date.now() / 6e4), first = Math.ceil((now + 20) / slot) * slot;
  const out: Flight[] = [];
  for (let m = first; m < now + 12 * 60; m += slot)
    for (const to of ORIGINS.filter((d) => d !== origin)) {
      const f = mockFlight(origin, to, m);
      if (hash(f.id) % 4 === 0) out.push(f); // ~25% of slots have a flight
    }
  return out;
}

/* ---------- Duffel ---------- */
// NOTE: Duffel offers don't expose remaining seat counts, so seatsLeft is derived from the offer id.
// Replace with your own inventory signal before launch.
function mapOffer(o: any): Flight {
  const seg = o.slices[0].segments[0];
  return { id: o.id, from: seg.origin.iata_code, to: seg.destination.iata_code, airline: seg.marketing_carrier.name,
    flightNo: `${seg.marketing_carrier.iata_code}${seg.marketing_carrier_flight_number}`, departure: new Date(seg.departing_at).toISOString(),
    basePrice: Math.round(parseFloat(o.total_amount)), seatsLeft: 4 + (hash(o.id) % 37) };
}
async function duffelFlights(origin: string): Promise<Flight[]> {
  const date = new Date().toISOString().slice(0, 10);
  const res = await Promise.all(ORIGINS.filter((d) => d !== origin).map(async (to) => {
    const r = await fetch(`${BASE}/air/offer_requests?return_offers=true`, { method: "POST", headers: headers(), cache: "no-store",
      body: JSON.stringify({ data: { slices: [{ origin, destination: to, departure_date: date }], passengers: [{ type: "adult" }], cabin_class: "economy" } }) });
    if (!r.ok) throw new Error(`Duffel ${r.status}`);
    return ((await r.json()).data.offers as any[]).map(mapOffer);
  }));
  // keep the cheapest offer per flight number
  const best = new Map<string, Flight>();
  res.flat().forEach((f) => { const k = f.flightNo + f.departure; if (!best.has(k) || best.get(k)!.basePrice > f.basePrice) best.set(k, f); });
  return [...best.values()];
}

/* ---------- Public API ---------- */
export async function getEmergencyFlights(origin: string): Promise<Flight[]> {
  let all: Flight[];
  try { all = KEY ? await duffelFlights(origin) : mockFlights(origin); }
  catch (e) { console.error(e); all = mockFlights(origin); }
  return all
    .filter((f) => { const h = hoursLeft(f.departure); return h > 0 && h <= 12 && f.seatsLeft > 10; })
    .sort((a, b) => +new Date(a.departure) - +new Date(b.departure));
}

export async function getFlight(id: string): Promise<Flight | null> {
  const m = id.match(/^([A-Z]{3})-([A-Z]{3})-(\d+)$/);
  if (m) return mockFlight(m[1], m[2], Number(m[3]));
  if (!KEY) return null;
  const r = await fetch(`${BASE}/air/offers/${encodeURIComponent(id)}`, { headers: headers(), cache: "no-store" });
  return r.ok ? mapOffer((await r.json()).data) : null;
}
