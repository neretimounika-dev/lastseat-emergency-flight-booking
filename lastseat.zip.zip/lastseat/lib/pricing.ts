// Single source of truth for discount rules (used by UI and server).
export const MIN_SEATS = 10; // only show when seatsLeft > 10
export const WINDOW_HOURS = 12;
export const hoursUntil = (iso: string, now = Date.now()) => (new Date(iso).getTime() - now) / 36e5;
export const timeDiscount = (h: number) => (h < 3 ? 60 : h < 6 ? 40 : 0);
export const discountFor = (h: number, offerPct = 0) => Math.max(timeDiscount(h), offerPct);
export const finalPrice = (base: number, pct: number) => Math.round((base * (100 - pct)) / 100);
export const isEmergency = (h: number) => h < 3;
