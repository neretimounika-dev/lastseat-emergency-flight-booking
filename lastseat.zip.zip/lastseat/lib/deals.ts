export type Flight = {
  id: string; from: string; to: string; airline: string; flightNo: string;
  departure: string; // ISO
  basePrice: number; seatsLeft: number;
};
export const ORIGINS = ["HYD", "BLR", "DEL", "MAA"] as const;
export const CITY: Record<string, string> = { HYD: "Hyderabad", BLR: "Bengaluru", DEL: "Delhi", MAA: "Chennai" };

export const hoursLeft = (iso: string) => (new Date(iso).getTime() - Date.now()) / 36e5;

export function badge(h: number) {
  if (h < 3) return { label: "60% OFF Emergency", pct: 60, emergency: true };
  if (h < 6) return { label: "40% OFF", pct: 40, emergency: false };
  return null;
}
export const finalPrice = (base: number, h: number) => Math.round(base * (1 - (badge(h)?.pct ?? 0) / 100));
